const SibApiV3Sdk = require("sib-api-v3-sdk");

// Initialize Brevo client
const client = SibApiV3Sdk.ApiClient.instance;

// Set API Key
const apiKey = client.authentications["api-key"];
apiKey.apiKey = process.env.BREVO_API_KEY;

// Initialize Transactional Email API
const tranEmailApi = new SibApiV3Sdk.TransactionalEmailsApi();

const sendMail = async (receiverEmail, id) => {
    try {

        const response = await tranEmailApi.sendTransacEmail({

            sender: {
                email: "zurikara9@gmail.com",
                name: "Chat application"
            },

            to: [
                {
                    email: receiverEmail
                }
            ],

            subject: "Reset Your Password",

            htmlContent: `
                <h2>Chat application</h2>
                <p>Click the button below to reset your password.</p>

                <a href="http://localhost:3000/password/resetpassword/${id}">
                    Reset Password
                </a>
            `
        });

        console.log("Mail sent successfully");
        console.log(response);

        return response;

    } catch (err) {

        console.log("BREVO ERROR:");

        // Print the full error
        console.log(err);

        // Print Brevo response if available
        console.log(err.response?.body);

        throw err;   // Let the controller know the mail failed
    }
};
module.exports = {
    sendMail
};